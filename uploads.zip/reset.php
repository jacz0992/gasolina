<?php
require 'db.php';
$msg = '';
$token = $_GET['token'] ?? '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $token = $_POST['token'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    // Verificar token válido y no expirado
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE reset_token = ? AND reset_expires > NOW()");
    $stmt->execute([$token]);
    
    if ($stmt->fetch()) {
        $pdo->prepare("UPDATE usuarios SET password=?, reset_token=NULL, reset_expires=NULL WHERE reset_token=?")
            ->execute([$pass, $token]);
        $msg = "<div class='alert alert-success'>¡Password cambiado! <a href='login.php'>Inicia sesión aquí</a></div>";
    } else {
        $msg = "<div class='alert alert-danger'>Token inválido o expirado.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nueva Contraseña - Tiger Tracker</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center justify-content-center vh-100">
    <div class="card shadow p-4" style="max-width: 400px; width: 100%;">
        <h3 class="text-center mb-4">🔒 Nuevo Password</h3>
        <?= $msg ?>
        <?php if(empty($msg)): ?>
        <form method="POST">
            <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
            <div class="mb-3">
                <label>Nueva Contraseña</label>
                <input type="password" name="password" class="form-control" required minlength="6">
            </div>
            <button type="submit" class="btn btn-primary w-100">Guardar Cambios</button>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>
