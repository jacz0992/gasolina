<?php
session_start();
$host = 'localhost';
$db   = 'u500271526_gasolina'; // Cambiar por tu nombre real de BD en Hostinger
$user = 'u500271526_gasolina';     // Cambiar por tu usuario real
$pass = 'M4r14&G4rd3l192!';  // Cambiar por tu contraseña
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("Error BD: " . $e->getMessage());
}

// Función para verificar login
function checkLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }
}
?>
