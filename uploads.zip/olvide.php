<?php
require 'db.php';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $pdo->prepare("UPDATE usuarios SET reset_token=?, reset_expires=? WHERE email=?")
            ->execute([$token, $expires, $email]);
            
        $link = "https://gasolina.loopcraft.com.co/reset.php?token=$token";
        $asunto = "Restaurar Password - Tiger Tracker";
        $mensaje = "Hola,\n\nPara resetear tu password, visita:\n$link\n\nEste enlace expira en 1 hora.";
        $headers = "From: no-reply@gasolina.loopcraft.com.co";
        
        mail($email, $asunto, $mensaje, $headers);
        $msg = "<div class='alert alert-success'>¡Revisa tu correo! Te enviamos un enlace.</div>";
    } else {
        $msg = "<div class='alert alert-danger'>Email no encontrado.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Recuperar - Tiger Tracker</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center justify-content-center vh-100">
    <div class="card shadow p-4" style="max-width: 400px; width: 100%;">
        <h3 class="text-center mb-4">🔑 Recuperar Acceso</h3>
        <?= $msg ?>
        <form method="POST">
            <div class="mb-3">
                <label>Tu Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-warning w-100">Enviar Enlace</button>
        </form>
        <div class="text-center mt-3">
            <a href="login.php">Volver al Login</a>
        </div>
    </div>
</body>
</html>
