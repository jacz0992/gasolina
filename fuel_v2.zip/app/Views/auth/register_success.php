<!DOCTYPE html>
<html>
<head><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light text-center py-5">
    <div class="container">
        <h1 class="display-4 text-success">¡Casi listo! ✉️</h1>
        <p class="lead">Hemos enviado un correo de confirmación.</p>
        <p>Revisa tu bandeja de entrada (y Spam) y haz clic en el enlace para activar tu cuenta.</p>
        <a href="?c=Auth" class="btn btn-primary">Volver al Login</a>
    </div>
</body>
</html>
